﻿namespace Server_01
{
    internal class ReverseLineReader
    {
        public ReverseLineReader()
        {
        }
    }
}